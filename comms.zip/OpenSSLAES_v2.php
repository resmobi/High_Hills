<?php
require_once('./Bytes.php');
class OpenSSLAES {
    private $secretKey = '';
    private $iv        = '';

	public function OpenSSLAES($key,$iv){
		$this->secretKey = $key;
		$this->iv = $iv;
	}

    public function decode($secretData){
		$decodeData = openssl_decrypt($secretData,'AES-128-CBC',$this->secretKey,OPENSSL_RAW_DATA,$this->iv);
		$unzipData = gzdecode($decodeData);
        return $unzipData;
    }
	//OPENSSL_RAW_DATA
    public function encode($data){
		$gzipData = gzencode($data,9,FORCE_GZIP);
        $data = openssl_encrypt($gzipData, 'AES-128-CBC', $this->secretKey, OPENSSL_RAW_DATA, $this->iv);		
        return $data;
    }
}