<?php

class PrivateKey{
    public  $key; 
    public  $iv; 
  
    function __construct($key, $iv=0)  
    {  
        $this->key = $key;  
        if($iv == 0)  
        {  
            $this->iv = $key;  
        }  
        else   
        {  
            $this->iv = $iv;  
        }  
    }  
  
  
    function encrypt($str)  
    {          
        $enc = mcrypt_encrypt(MCRYPT_BLOWFISH, $this->key, $str, MCRYPT_MODE_ECB, $this->iv); 
		//$end = openssl_decrypt($str, 'AES-128-ECB', $this->key,2);
		$end = gzencode($enc,9,FORCE_GZIP);
        return base64_encode($end); 
    } 
      
    //����  
    function decrypt($str)  
    {   
  
            $encrypt = base64_decode($str);
            $data = gzdecode($encrypt);

            //retrieves the IV, iv_size should be created using mcrypt_get_iv_size()
            $iv_size = mcrypt_get_iv_size(MCRYPT_BLOWFISH, MCRYPT_MODE_ECB);  
        
            // retrieves the cipher text (everything except the $iv_size in the front)
            $iv = substr($data, 0, $iv_size);
            $str = substr($data, $iv_size);
            
            //get the plain text
            return mcrypt_decrypt(MCRYPT_BLOWFISH, $this->key, $data, MCRYPT_MODE_CBC, $iv);
        
    }  
}
