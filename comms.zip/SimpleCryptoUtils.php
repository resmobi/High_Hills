<?php
class SimpleCryptoUtils {
	public static function DecodeData($data) {
		try {
			$len= count( $data );
			
			$data [0] = (($data [0] >> 4) & 0x0F) | (($data [0] << 4) & 0xF0);
			for($i = 1; $i < $len; $i ++)
				$data [$i] = ($data [$i] & 0xFF) ^ ($data [$i - 1] & 0xFF);
			return $data; // new String(data, 0, len,"utf-8");
		} catch ( Exception $ioe ) {
		}
		return null;
	}
	public static function EncodeData($inData) {
		try {
			if ($inData == null)
				return null;
			$data1 = $inData;
			$len = count ( $inData );
			
			$data [0] = (($data1 [0] >> 4) & 0x0F) | (($data1 [0] << 4) & 0xF0);
			
			for($i = 1; $i < $len; $i ++) {
				$data [$i] = ($data1 [$i] & 0xFF) ^ ($data1 [$i - 1] & 0xFF);
			}
			return $data;
		} catch ( Exception $e ) {
		}
		return null;
	}
}
