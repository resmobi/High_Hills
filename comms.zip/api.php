<?php
        require_once('./OpenSSLAES_v2.php');


      //$pk = $_POST['pk'];
      //$r = $_POST['en'];
        $r=1;
        $key = 'AuOf#lgN2kY)nU9B';
        $iv = '8MkxR)XeAO$3ESBP';

        //$pkey = new PrivateKey($key,$iv);

//      if ($r)
//      {
//              $query = $pkey->decrypt($r); 
//              $pk = GetUrlParam('pk', $query);
//      }  


        $dsn = 'mysql:dbname=vp_db;host=127.0.0.1:3306';
        $user = 'root';
        $password = 'msWd@jt0906_03';

        try {
                $pdo = new PDO($dsn, $user, $password);
        } catch (PDOException $e) {
                echo 'Connection failed: ' . $e->getMessage();
                exit();
        }
        $servers=GetAll(0);

        if (!$servers)
        {
                //exit(0);
        }




        $ret = array();

        $ret["servers"] = $servers;


        //$ret["tcp_port"] = array(443);

        $ret["tip_intervals"] = 3;

        $ret["max_trials"] = 10;

        $ret["invite_ui"] = 2;

        if ($r)
        {
                Output($ret,$iv,$key);
        }
        else
                echo json_encode($ret);


        function GetAll($vip=0,$max_node=5)
        {
                global $pdo;

                $sql = "SELECT server_ip,country,country_name,city,alisa_name,oports,tports,round((tx)/1000000) as 'load',icon,`weight` FROM tb_server_ss WHERE status=1 and  tx < 150000000 ORDER by country_name DESC,id DESC";
  

                $ret = array();

                $k=0;
                foreach ($pdo->query($sql) as $row)
                {
                        if ($row)
                        {
                                if (intval($row['load'])>100)
                                        continue;

                                $ret[$k]['ccode'] = $row['country'];
                                $ret[$k]['cname'] = $row['country_name'];
                                $ret[$k]['city'] = $row['city'];
                                $ret[$k]['alisa'] = $row['alisa_name'];
                                $ret[$k]['ovtcp'] = array(102,8080,443);
                                $ret[$k]['ovudp'] = array(110,119,800);
								$ret[$k]['ikeudp'] = array(500,68,4500);								
                                $ret[$k]['host'] = $row['server_ip'];
                                $ret[$k]['load'] = intval($row['load']);
                                $ret[$k]['icon'] = $row['icon'];
								$ret[$k]['weight']=intval($row['weight']);

                                $k++;
                                //var_dump($ret);
                        }
                }

                return $ret;
        }

        function Output($ret_value,$iv,$key)
        {
                global $r;
	//	var_dump(json_encode($ret_value));exit;

                if ($r)
                {
                        //$enstr = $code->xcode(json_encode($ret_value));
                        $data = json_encode($ret_value);
                        //$enstr = $pkey->encrypt($data);
						$aes = new OpenSSLAES($key,$iv);
						$endstr = $aes->encode($data); 
                        echo $endstr;
                }else
                        echo json_encode($ret_value);
        }
?>
